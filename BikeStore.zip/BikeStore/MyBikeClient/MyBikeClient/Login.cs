﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace MyBikeClient
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        public class Person
        {
            private string id;
            private string name;

            public string Id { get => id; set => id = value; }
            public string Name { get => name; set => name = value; }
        }

        public static String txtFilePath = @"../../data/log.txt";
        public static List<Person> ReadFromTextFile()
        {
            
            try
            {
                List<Person> list = new List<Person>();
                StreamReader sr = new StreamReader(txtFilePath);

                String line = null;

                while ((line = sr.ReadLine()) != null)
                {
                    Person aPerson = new Person();

                    String[] fields = line.Split('|');

                    aPerson.Id = fields[0];
                    aPerson.Name = fields[1];


                    list.Add(aPerson);

                }

                sr.Close();
                return list;

            }
            catch (IOException ioex)
            {
                Console.WriteLine(ioex.Message);
            }
            return null;
        }
        private void Login_Load(object sender, EventArgs e)
        {
            this.txtUser.Focus();
        }
        private void btnLog_Click(object sender, EventArgs e)
        {
            List<Person> personList = new List<Person>();
            personList = ReadFromTextFile();

            if (!String.IsNullOrEmpty(txtPass.Text)
                && !String.IsNullOrEmpty(txtUser.Text))
            {
                foreach (Person A in personList)
                {
                    if (A.Id == txtPass.Text && A.Name == txtUser.Text)
                    {
                        Form1 fs = new Form1();
                        fs.Show();
                        this.txtUser.Text = "";
                        this.txtPass.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Please enter valid username and password",
                                                        "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtUser.Text = "";
                        this.txtPass.Text = "";
                    }
                }
            }

        }

        
    }
}
