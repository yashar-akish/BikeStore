﻿namespace MyBikeClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTire = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtSpeed = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtMade = new System.Windows.Forms.TextBox();
            this.txtSN = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblinchR = new System.Windows.Forms.Label();
            this.lblinchM = new System.Windows.Forms.Label();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.cmbSuspension = new System.Windows.Forms.ComboBox();
            this.txtSeat = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.rdrRoad = new System.Windows.Forms.RadioButton();
            this.rdrMountain = new System.Windows.Forms.RadioButton();
            this.lblsz = new System.Windows.Forms.Label();
            this.lblset = new System.Windows.Forms.Label();
            this.lblhgh = new System.Windows.Forms.Label();
            this.lblsus = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.listBoxRoad = new System.Windows.Forms.ListBox();
            this.listBoxMontain = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.listBoxTextFile = new System.Windows.Forms.ListBox();
            this.btnRESET = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.btnROADlist = new System.Windows.Forms.Button();
            this.bntMOUNTlist = new System.Windows.Forms.Button();
            this.btnALLlist = new System.Windows.Forms.Button();
            this.btnToList = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnSEARCH = new System.Windows.Forms.Button();
            this.btnREMOVE = new System.Windows.Forms.Button();
            this.btnDISALL = new System.Windows.Forms.Button();
            this.btnUPDATE = new System.Windows.Forms.Button();
            this.btnADDtoText = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbColor = new System.Windows.Forms.ComboBox();
            this.textNewS = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(683, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 20);
            this.label14.TabIndex = 56;
            this.label14.Text = "Kg";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(883, 86);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 20);
            this.label12.TabIndex = 55;
            this.label12.Text = "Km/H";
            // 
            // txtTire
            // 
            this.txtTire.Location = new System.Drawing.Point(778, 128);
            this.txtTire.Name = "txtTire";
            this.txtTire.Size = new System.Drawing.Size(100, 26);
            this.txtTire.TabIndex = 54;
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(577, 126);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(100, 26);
            this.txtWeight.TabIndex = 53;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(370, 124);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(100, 26);
            this.txtDate.TabIndex = 52;
            // 
            // txtSpeed
            // 
            this.txtSpeed.Location = new System.Drawing.Point(778, 86);
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.Size = new System.Drawing.Size(100, 26);
            this.txtSpeed.TabIndex = 50;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(577, 86);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(100, 26);
            this.txtModel.TabIndex = 49;
            // 
            // txtMade
            // 
            this.txtMade.Location = new System.Drawing.Point(371, 86);
            this.txtMade.Name = "txtMade";
            this.txtMade.Size = new System.Drawing.Size(100, 26);
            this.txtMade.TabIndex = 48;
            // 
            // txtSN
            // 
            this.txtSN.Location = new System.Drawing.Point(169, 86);
            this.txtSN.Name = "txtSN";
            this.txtSN.Size = new System.Drawing.Size(100, 26);
            this.txtSN.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(708, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 23);
            this.label6.TabIndex = 46;
            this.label6.Text = "Tire Size";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(489, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 23);
            this.label7.TabIndex = 45;
            this.label7.Text = "Weight";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(267, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 23);
            this.label8.TabIndex = 44;
            this.label8.Text = "Made Date";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(17, 128);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 23);
            this.label9.TabIndex = 43;
            this.label9.Text = "Color";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(699, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 42;
            this.label5.Text = "Speed";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(485, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Model";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(283, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 40;
            this.label3.Text = "Made";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(37, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 20);
            this.label2.TabIndex = 39;
            this.label2.Text = "Serial Number";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblinchR);
            this.groupBox1.Controls.Add(this.lblinchM);
            this.groupBox1.Controls.Add(this.cmbSize);
            this.groupBox1.Controls.Add(this.cmbSuspension);
            this.groupBox1.Controls.Add(this.txtSeat);
            this.groupBox1.Controls.Add(this.txtHeight);
            this.groupBox1.Controls.Add(this.rdrRoad);
            this.groupBox1.Controls.Add(this.rdrMountain);
            this.groupBox1.Controls.Add(this.lblsz);
            this.groupBox1.Controls.Add(this.lblset);
            this.groupBox1.Controls.Add(this.lblhgh);
            this.groupBox1.Controls.Add(this.lblsus);
            this.groupBox1.Location = new System.Drawing.Point(41, 179);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(879, 128);
            this.groupBox1.TabIndex = 57;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bike Type";
            // 
            // lblinchR
            // 
            this.lblinchR.AutoSize = true;
            this.lblinchR.Location = new System.Drawing.Point(504, 86);
            this.lblinchR.Name = "lblinchR";
            this.lblinchR.Size = new System.Drawing.Size(38, 20);
            this.lblinchR.TabIndex = 40;
            this.lblinchR.Text = "inch";
            // 
            // lblinchM
            // 
            this.lblinchM.AutoSize = true;
            this.lblinchM.Location = new System.Drawing.Point(505, 34);
            this.lblinchM.Name = "lblinchM";
            this.lblinchM.Size = new System.Drawing.Size(38, 20);
            this.lblinchM.TabIndex = 39;
            this.lblinchM.Text = "inch";
            // 
            // cmbSize
            // 
            this.cmbSize.FormattingEnabled = true;
            this.cmbSize.Location = new System.Drawing.Point(656, 78);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(121, 28);
            this.cmbSize.TabIndex = 26;
            this.cmbSize.Visible = false;
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged_1);
            // 
            // cmbSuspension
            // 
            this.cmbSuspension.FormattingEnabled = true;
            this.cmbSuspension.Location = new System.Drawing.Point(656, 28);
            this.cmbSuspension.Name = "cmbSuspension";
            this.cmbSuspension.Size = new System.Drawing.Size(121, 28);
            this.cmbSuspension.TabIndex = 25;
            this.cmbSuspension.Visible = false;
            this.cmbSuspension.SelectedIndexChanged += new System.EventHandler(this.cmbSuspension_SelectedIndexChanged_1);
            // 
            // txtSeat
            // 
            this.txtSeat.Location = new System.Drawing.Point(398, 80);
            this.txtSeat.Name = "txtSeat";
            this.txtSeat.Size = new System.Drawing.Size(100, 26);
            this.txtSeat.TabIndex = 24;
            this.txtSeat.Visible = false;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(398, 28);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(100, 26);
            this.txtHeight.TabIndex = 23;
            this.txtHeight.Visible = false;
            // 
            // rdrRoad
            // 
            this.rdrRoad.AutoSize = true;
            this.rdrRoad.Location = new System.Drawing.Point(112, 82);
            this.rdrRoad.Name = "rdrRoad";
            this.rdrRoad.Size = new System.Drawing.Size(116, 24);
            this.rdrRoad.TabIndex = 22;
            this.rdrRoad.Text = "Road Bikes";
            this.rdrRoad.UseVisualStyleBackColor = true;
            this.rdrRoad.CheckedChanged += new System.EventHandler(this.rdrRoad_CheckedChanged_1);
            // 
            // rdrMountain
            // 
            this.rdrMountain.AutoSize = true;
            this.rdrMountain.Location = new System.Drawing.Point(112, 25);
            this.rdrMountain.Name = "rdrMountain";
            this.rdrMountain.Size = new System.Drawing.Size(143, 24);
            this.rdrMountain.TabIndex = 21;
            this.rdrMountain.Text = "Mountain Bikes";
            this.rdrMountain.UseVisualStyleBackColor = true;
            this.rdrMountain.CheckedChanged += new System.EventHandler(this.rdrMountain_CheckedChanged_1);
            // 
            // lblsz
            // 
            this.lblsz.Location = new System.Drawing.Point(539, 82);
            this.lblsz.Name = "lblsz";
            this.lblsz.Size = new System.Drawing.Size(111, 23);
            this.lblsz.TabIndex = 12;
            this.lblsz.Text = "Size";
            this.lblsz.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblsz.Visible = false;
            // 
            // lblset
            // 
            this.lblset.Location = new System.Drawing.Point(281, 83);
            this.lblset.Name = "lblset";
            this.lblset.Size = new System.Drawing.Size(111, 23);
            this.lblset.TabIndex = 11;
            this.lblset.Text = "Seat Heigth";
            this.lblset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblset.Visible = false;
            // 
            // lblhgh
            // 
            this.lblhgh.Location = new System.Drawing.Point(281, 31);
            this.lblhgh.Name = "lblhgh";
            this.lblhgh.Size = new System.Drawing.Size(111, 23);
            this.lblhgh.TabIndex = 10;
            this.lblhgh.Text = "Heigth";
            this.lblhgh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblhgh.Visible = false;
            // 
            // lblsus
            // 
            this.lblsus.Location = new System.Drawing.Point(542, 30);
            this.lblsus.Name = "lblsus";
            this.lblsus.Size = new System.Drawing.Size(111, 23);
            this.lblsus.TabIndex = 9;
            this.lblsus.Text = "Suspension";
            this.lblsus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblsus.Visible = false;
            // 
            // label17
            // 
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(16, 339);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(1870, 12);
            this.label17.TabIndex = 58;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(220, 816);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(303, 23);
            this.label16.TabIndex = 64;
            this.label16.Text = "List of Road Bikes from the list";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(220, 643);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(303, 23);
            this.label15.TabIndex = 63;
            this.label15.Text = "List of Mountain Bikes from the list";
            // 
            // listBoxRoad
            // 
            this.listBoxRoad.BackColor = System.Drawing.SystemColors.Window;
            this.listBoxRoad.FormattingEnabled = true;
            this.listBoxRoad.ItemHeight = 20;
            this.listBoxRoad.Location = new System.Drawing.Point(214, 842);
            this.listBoxRoad.Name = "listBoxRoad";
            this.listBoxRoad.Size = new System.Drawing.Size(1473, 124);
            this.listBoxRoad.TabIndex = 62;
            this.listBoxRoad.SelectedIndexChanged += new System.EventHandler(this.listBoxRoad_SelectedIndexChanged_1);
            // 
            // listBoxMontain
            // 
            this.listBoxMontain.BackColor = System.Drawing.SystemColors.Window;
            this.listBoxMontain.FormattingEnabled = true;
            this.listBoxMontain.ItemHeight = 20;
            this.listBoxMontain.Location = new System.Drawing.Point(214, 669);
            this.listBoxMontain.Name = "listBoxMontain";
            this.listBoxMontain.Size = new System.Drawing.Size(1473, 124);
            this.listBoxMontain.TabIndex = 61;
            this.listBoxMontain.SelectedIndexChanged += new System.EventHandler(this.listBoxMontain_SelectedIndexChanged_1);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(220, 385);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(303, 23);
            this.label11.TabIndex = 60;
            this.label11.Text = "List of Bikes from XMLFile";
            // 
            // listBoxTextFile
            // 
            this.listBoxTextFile.BackColor = System.Drawing.SystemColors.Window;
            this.listBoxTextFile.FormattingEnabled = true;
            this.listBoxTextFile.ItemHeight = 20;
            this.listBoxTextFile.Location = new System.Drawing.Point(214, 411);
            this.listBoxTextFile.Name = "listBoxTextFile";
            this.listBoxTextFile.Size = new System.Drawing.Size(1473, 204);
            this.listBoxTextFile.TabIndex = 59;
            // 
            // btnRESET
            // 
            this.btnRESET.BackColor = System.Drawing.Color.Silver;
            this.btnRESET.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRESET.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRESET.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnRESET.Location = new System.Drawing.Point(887, 354);
            this.btnRESET.Name = "btnRESET";
            this.btnRESET.Size = new System.Drawing.Size(247, 44);
            this.btnRESET.TabIndex = 65;
            this.btnRESET.Text = "RESET";
            this.btnRESET.UseVisualStyleBackColor = false;
            this.btnRESET.Click += new System.EventHandler(this.btnRESET_Click_1);
            // 
            // label18
            // 
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Location = new System.Drawing.Point(1070, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 249);
            this.label18.TabIndex = 77;
            // 
            // btnROADlist
            // 
            this.btnROADlist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnROADlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnROADlist.ForeColor = System.Drawing.Color.Black;
            this.btnROADlist.Location = new System.Drawing.Point(1365, 245);
            this.btnROADlist.Name = "btnROADlist";
            this.btnROADlist.Size = new System.Drawing.Size(96, 57);
            this.btnROADlist.TabIndex = 76;
            this.btnROADlist.Text = "DISPLAY ROADS";
            this.btnROADlist.UseVisualStyleBackColor = true;
            this.btnROADlist.Click += new System.EventHandler(this.btnROADlist_Click_1);
            // 
            // bntMOUNTlist
            // 
            this.bntMOUNTlist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bntMOUNTlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntMOUNTlist.ForeColor = System.Drawing.Color.Black;
            this.bntMOUNTlist.Location = new System.Drawing.Point(1239, 245);
            this.bntMOUNTlist.Name = "bntMOUNTlist";
            this.bntMOUNTlist.Size = new System.Drawing.Size(106, 57);
            this.bntMOUNTlist.TabIndex = 75;
            this.bntMOUNTlist.Text = "DISPLAY MOUNTAINS";
            this.bntMOUNTlist.UseVisualStyleBackColor = true;
            this.bntMOUNTlist.Click += new System.EventHandler(this.bntMOUNTlist_Click_1);
            // 
            // btnALLlist
            // 
            this.btnALLlist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnALLlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnALLlist.ForeColor = System.Drawing.Color.Black;
            this.btnALLlist.Location = new System.Drawing.Point(1121, 244);
            this.btnALLlist.Name = "btnALLlist";
            this.btnALLlist.Size = new System.Drawing.Size(96, 57);
            this.btnALLlist.TabIndex = 74;
            this.btnALLlist.Text = "DISPLAY ALL";
            this.btnALLlist.UseVisualStyleBackColor = true;
            this.btnALLlist.Click += new System.EventHandler(this.btnALLlist_Click_1);
            // 
            // btnToList
            // 
            this.btnToList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnToList.Location = new System.Drawing.Point(1121, 90);
            this.btnToList.Name = "btnToList";
            this.btnToList.Size = new System.Drawing.Size(96, 57);
            this.btnToList.TabIndex = 73;
            this.btnToList.Text = "ADD to LIST";
            this.btnToList.UseVisualStyleBackColor = true;
            this.btnToList.Click += new System.EventHandler(this.btnToList_Click_1);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(1541, 271);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(200, 26);
            this.txtSearch.TabIndex = 72;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(1627, 240);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 23);
            this.label13.TabIndex = 71;
            this.label13.Text = "Serial Number";
            // 
            // btnSEARCH
            // 
            this.btnSEARCH.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSEARCH.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSEARCH.Location = new System.Drawing.Point(1773, 240);
            this.btnSEARCH.Name = "btnSEARCH";
            this.btnSEARCH.Size = new System.Drawing.Size(96, 57);
            this.btnSEARCH.TabIndex = 70;
            this.btnSEARCH.Text = "SEARCH";
            this.btnSEARCH.UseVisualStyleBackColor = true;
            this.btnSEARCH.Click += new System.EventHandler(this.btnSEARCH_Click_1);
            // 
            // btnREMOVE
            // 
            this.btnREMOVE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnREMOVE.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnREMOVE.ForeColor = System.Drawing.Color.Red;
            this.btnREMOVE.Location = new System.Drawing.Point(1239, 90);
            this.btnREMOVE.Name = "btnREMOVE";
            this.btnREMOVE.Size = new System.Drawing.Size(96, 57);
            this.btnREMOVE.TabIndex = 69;
            this.btnREMOVE.Text = "REMOVE";
            this.btnREMOVE.UseVisualStyleBackColor = true;
            this.btnREMOVE.Click += new System.EventHandler(this.btnREMOVE_Click_1);
            // 
            // btnDISALL
            // 
            this.btnDISALL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDISALL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDISALL.Location = new System.Drawing.Point(1613, 151);
            this.btnDISALL.Name = "btnDISALL";
            this.btnDISALL.Size = new System.Drawing.Size(256, 45);
            this.btnDISALL.TabIndex = 68;
            this.btnDISALL.Text = "READ ALL from THE TEXT FILE";
            this.btnDISALL.UseVisualStyleBackColor = true;
            this.btnDISALL.Click += new System.EventHandler(this.btnDISALL_Click_1);
            // 
            // btnUPDATE
            // 
            this.btnUPDATE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnUPDATE.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUPDATE.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnUPDATE.Location = new System.Drawing.Point(1121, 171);
            this.btnUPDATE.Name = "btnUPDATE";
            this.btnUPDATE.Size = new System.Drawing.Size(96, 57);
            this.btnUPDATE.TabIndex = 67;
            this.btnUPDATE.Text = "UPDATE";
            this.btnUPDATE.UseVisualStyleBackColor = true;
            this.btnUPDATE.Click += new System.EventHandler(this.btnUPDATE_Click_1);
            // 
            // btnADDtoText
            // 
            this.btnADDtoText.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnADDtoText.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADDtoText.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnADDtoText.Location = new System.Drawing.Point(1613, 96);
            this.btnADDtoText.Name = "btnADDtoText";
            this.btnADDtoText.Size = new System.Drawing.Size(256, 43);
            this.btnADDtoText.TabIndex = 66;
            this.btnADDtoText.Text = "WRITE to TEXT FILE";
            this.btnADDtoText.UseVisualStyleBackColor = true;
            this.btnADDtoText.Click += new System.EventHandler(this.btnADDtoText_Click_2);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(403, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1032, 38);
            this.label1.TabIndex = 78;
            this.label1.Text = "My Bikes store ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbColor
            // 
            this.cmbColor.FormattingEnabled = true;
            this.cmbColor.Location = new System.Drawing.Point(134, 122);
            this.cmbColor.Name = "cmbColor";
            this.cmbColor.Size = new System.Drawing.Size(135, 28);
            this.cmbColor.TabIndex = 79;
            this.cmbColor.SelectedIndexChanged += new System.EventHandler(this.cmbColor_SelectedIndexChanged);
            // 
            // textNewS
            // 
            this.textNewS.Location = new System.Drawing.Point(950, 228);
            this.textNewS.Name = "textNewS";
            this.textNewS.Size = new System.Drawing.Size(100, 26);
            this.textNewS.TabIndex = 81;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(946, 184);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 23);
            this.label10.TabIndex = 80;
            this.label10.Text = "New Speed";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(884, 134);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 20);
            this.label19.TabIndex = 82;
            this.label19.Text = "inch";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 983);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textNewS);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbColor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnROADlist);
            this.Controls.Add(this.bntMOUNTlist);
            this.Controls.Add(this.btnALLlist);
            this.Controls.Add(this.btnToList);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnSEARCH);
            this.Controls.Add(this.btnREMOVE);
            this.Controls.Add(this.btnDISALL);
            this.Controls.Add(this.btnUPDATE);
            this.Controls.Add(this.btnADDtoText);
            this.Controls.Add(this.btnRESET);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.listBoxRoad);
            this.Controls.Add(this.listBoxMontain);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.listBoxTextFile);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtTire);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtSpeed);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtMade);
            this.Controls.Add(this.txtSN);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Selling form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTire;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtSpeed;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtMade;
        private System.Windows.Forms.TextBox txtSN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblinchR;
        private System.Windows.Forms.Label lblinchM;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.ComboBox cmbSuspension;
        private System.Windows.Forms.TextBox txtSeat;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.RadioButton rdrRoad;
        private System.Windows.Forms.RadioButton rdrMountain;
        private System.Windows.Forms.Label lblsz;
        private System.Windows.Forms.Label lblset;
        private System.Windows.Forms.Label lblhgh;
        private System.Windows.Forms.Label lblsus;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox listBoxRoad;
        private System.Windows.Forms.ListBox listBoxMontain;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox listBoxTextFile;
        private System.Windows.Forms.Button btnRESET;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnROADlist;
        private System.Windows.Forms.Button bntMOUNTlist;
        private System.Windows.Forms.Button btnALLlist;
        private System.Windows.Forms.Button btnToList;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnSEARCH;
        private System.Windows.Forms.Button btnREMOVE;
        private System.Windows.Forms.Button btnDISALL;
        private System.Windows.Forms.Button btnUPDATE;
        private System.Windows.Forms.Button btnADDtoText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbColor;
        private System.Windows.Forms.TextBox textNewS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label19;
    }
}

