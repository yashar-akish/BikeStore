﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyBikeBus;
using MyBikeData;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace MyBikeClient
{
    public partial class Form1 : Form
    {


        List<Bike> Bikelist = new List<Bike>();
        List<MountainBike> MountainBikeList = new List<MountainBike>();
        List<RoadBike> RoadBikeList = new List<RoadBike>();

        int index = -1;
        int indexM = -1;
        int indexR = -1;
        int positionMountain = -1;
        int positionRoad = -1;
        int positionColor = -1;
        public Form1()
        {
            InitializeComponent();
        }


        private void rdrMountain_CheckedChanged_1(object sender, EventArgs e)
        {
            lblsus.Visible = lblhgh.Visible = cmbSuspension.Visible = txtHeight.Visible = lblinchM.Visible = true;
            lblset.Visible = lblsz.Visible = cmbSize.Visible = txtSeat.Visible = lblinchR.Visible = false;
        }

        private void rdrRoad_CheckedChanged_1(object sender, EventArgs e)
        {
            lblsus.Visible = lblhgh.Visible = cmbSuspension.Visible = txtHeight.Visible = lblinchM.Visible = false;
            lblset.Visible = lblsz.Visible = cmbSize.Visible = txtSeat.Visible = lblinchR.Visible = true;
        }

        private void cmbColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.positionColor = this.cmbColor.SelectedIndex;
        }

        private void cmbSuspension_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            this.positionMountain = this.cmbSuspension.SelectedIndex;
        }

        private void cmbSize_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            this.positionRoad = this.cmbSize.SelectedIndex;
        }


        private void Form1_Load_1(object sender, EventArgs e)
        {
            this.txtSN.Focus();
            this.rdrMountain.Checked = this.rdrRoad.Checked = this.lblinchM.Visible = this.lblinchR.Visible = false;
            foreach (EnumMountain item in Enum.GetValues(typeof(EnumMountain)))
            {
                this.cmbSuspension.Items.Add(item);
            }
            this.cmbSuspension.Text = Convert.ToString(this.cmbSuspension.Items[0]);

            foreach (EnumRoad item in Enum.GetValues(typeof(EnumRoad)))
            {
                this.cmbSize.Items.Add(item);
            }
            this.cmbSize.Text = Convert.ToString(this.cmbSize.Items[0]);

            foreach (EnumColor item in Enum.GetValues(typeof(EnumColor)))
            {
                this.cmbColor.Items.Add(item);
            }
            this.cmbColor.Text = Convert.ToString(this.cmbColor.Items[0]);
        }

        private void btnToList_Click_1(object sender, EventArgs e)
        {

            //++++++++++++++++++++++ validation
            bool correct = false;


            if (RegExValidator.Is12Digit(txtSN.Text))
                correct = true;
            if (!correct) MessageBox.Show("you must input 12 digit for serial number",
                                                "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;


            correct = false;

            //if (RegExValidator.IsDecimal(txtHeight.Text) || RegExValidator.IsDecimal(txtSeat.Text))
            //    correct = true;
            //if (!correct) MessageBox.Show("you must input decimal number",
            //                                    "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;

            //correct = false;

            if (RegExValidator.IsAlphabetNumber(txtMade.Text))
                correct = true;
            if (!correct) MessageBox.Show("you must input characteer for made",
                                                "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;


            correct = false;

            if (RegExValidator.IsEmpty(txtSN.Text) || RegExValidator.IsEmpty(txtMade.Text) || RegExValidator.IsEmpty(txtModel.Text) || RegExValidator.IsEmpty(txtDate.Text)
                || RegExValidator.IsEmpty(txtSpeed.Text) || RegExValidator.IsEmpty(txtWeight.Text) || RegExValidator.IsEmpty(textNewS.Text))
                correct = true;
            if (!correct) MessageBox.Show("you must not leave empty",
                                                "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning); ;
            //Bike theMountain = new MountainBike();
            //MountainBike mountain = (MountainBike)theMountain;

            //Bike theRoad = new RoadBike();
            //RoadBike Road = (RoadBike)theRoad;
            //++++++++++++++++++++++++++++++++++++++++++++++++
            this.btnUPDATE.Visible = true;
            if (rdrMountain.Checked)
            {
                if (!String.IsNullOrEmpty(txtSN.Text)
                && !String.IsNullOrEmpty(txtMade.Text)
                && !String.IsNullOrEmpty(txtModel.Text)
                && !String.IsNullOrEmpty(txtDate.Text)
                && !String.IsNullOrEmpty(txtSpeed.Text)
                && !String.IsNullOrEmpty(txtWeight.Text)
                && !String.IsNullOrEmpty(txtTire.Text)
                && !String.IsNullOrEmpty(txtHeight.Text))
                {

                    long serialNumber = Convert.ToInt64(this.txtSN.Text);
                    string model = this.txtModel.Text;
                    string made = this.txtMade.Text;
                    EnumColor color = (EnumColor)positionMountain;
                    double weight = Convert.ToDouble(this.txtWeight.Text);
                    int tireSize = Convert.ToInt32(this.txtTire.Text);
                    EnumBikeType type = EnumBikeType.Mountain_Bike;
                    double speed = Convert.ToInt64(this.txtSpeed.Text);
                    int height = Convert.ToInt32(this.txtHeight.Text);
                    EnumMountain suspension = (EnumMountain)positionMountain;
                    double newSpeed = Convert.ToDouble(this.textNewS.Text);
                    int madeDate = Convert.ToInt32(this.txtDate.Text);


                    MountainBike aMountain = new MountainBike(type, serialNumber, made, model,
                                speed, color, madeDate, weight, tireSize, newSpeed, height, suspension);

                    MountainBikeList.Add(aMountain);
                    Bikelist.Add(aMountain);
                    listBoxMontain.Items.Add(aMountain);

                }
                else
                {
                    MessageBox.Show("you must input data\n data is requared...",
                                                    "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


            if (rdrRoad.Checked)
            {
                if (!String.IsNullOrEmpty(txtSN.Text)
                && !String.IsNullOrEmpty(txtMade.Text)
                && !String.IsNullOrEmpty(txtModel.Text)
                && !String.IsNullOrEmpty(txtDate.Text)
                && !String.IsNullOrEmpty(txtSpeed.Text)
                && !String.IsNullOrEmpty(txtWeight.Text)
                && !String.IsNullOrEmpty(txtTire.Text)
                && !String.IsNullOrEmpty(txtSeat.Text))
                {
                    long serialNumber = Convert.ToInt64(this.txtSN.Text);
                    string model = this.txtModel.Text;
                    string made = this.txtMade.Text;
                    EnumColor color = (EnumColor)positionColor;
                    double weight = Convert.ToDouble(this.txtWeight.Text);
                    int tireSize = Convert.ToInt32(this.txtTire.Text);
                    EnumBikeType type = EnumBikeType.Mountain_Bike;
                    double speed = Convert.ToInt64(this.txtSpeed.Text);
                    int seatHeight = Convert.ToInt32(this.txtSeat.Text);
                    EnumRoad size = (EnumRoad)positionRoad;
                    double newSpeed = Convert.ToDouble(this.textNewS.Text);
                    int madeDate = Convert.ToInt32(this.txtDate.Text);


                    RoadBike aRoad = new RoadBike(type, serialNumber, made, model,
                               speed, color, madeDate, weight, tireSize, newSpeed, seatHeight, size);

                    RoadBikeList.Add(aRoad);
                    Bikelist.Add(aRoad);
                    listBoxRoad.Items.Add(aRoad);
                }
                else
                {
                    MessageBox.Show("you must input data\n data is requared...",
                                                    "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnALLlist_Click_1(object sender, EventArgs e)
        {
            this.listBoxTextFile.Items.Clear();
            this.listBoxMontain.Items.Clear();
            this.listBoxRoad.Items.Clear();
            if (MountainBikeList.Count > 0)
            {
                foreach (Bike bk in MountainBikeList)
                {
                    this.listBoxMontain.Items.Add(bk);
                }
            }
            else MessageBox.Show("The \"Mountain Bike\"list is empty");
            if (RoadBikeList.Count > 0)
            {
                foreach (Bike bk in RoadBikeList)
                {
                    this.listBoxRoad.Items.Add(bk);
                }
            }
            else MessageBox.Show("The \"Road Bike\"list is empty");
        }

        private void bntMOUNTlist_Click_1(object sender, EventArgs e)
        {
            this.listBoxTextFile.Items.Clear();
            this.listBoxMontain.Items.Clear();
            this.listBoxRoad.Items.Clear();

            if (MountainBikeList.Count > 0)
            {
                foreach (Bike bk in MountainBikeList)
                {
                    this.listBoxMontain.Items.Add(bk);
                }
            }
            else MessageBox.Show("The list is empty");
        }

        private void btnROADlist_Click_1(object sender, EventArgs e)
        {
            this.listBoxTextFile.Items.Clear();
            this.listBoxMontain.Items.Clear();
            this.listBoxRoad.Items.Clear();

            if (RoadBikeList.Count > 0)
            {
                foreach (Bike bk in RoadBikeList)
                {
                    this.listBoxRoad.Items.Add(bk);
                }
            }
            else MessageBox.Show("The list is empty");
        }

        private void btnADDtoText_Click_2(object sender, EventArgs e)
        {
            this.btnUPDATE.Visible = true;

            FileHandler.WriteToXmlFile(Bikelist);
        }

        private void btnDISALL_Click_1(object sender, EventArgs e)
        {
            this.listBoxTextFile.Items.Clear();
            List<Bike> list = new List<Bike>();
            list = FileHandler.ReadFromXmlFile();

            if (list.Count > 0)
            {
                foreach (Bike bk in list)
                {
                    this.listBoxTextFile.Items.Add(bk);
                }
            }
        }

        private void btnSEARCH_Click_1(object sender, EventArgs e)
        {
            this.btnUPDATE.Visible = true;
            bool found = false;


            if (String.IsNullOrEmpty(txtSearch.Text))
            {
                MessageBox.Show(" Enter valid number ");
            }
            Bike aBike = null;

            

            long key = Convert.ToInt64(this.txtSearch.Text);
            foreach (Bike record in this.Bikelist)
            {
                if ( record.SerialNumber == key)
                {
                    found = true;
                    aBike = record;
                    break;
                }
            }

            if (found) MessageBox.Show(" The Bike info is : \n" + Convert.ToString(aBike));
            else MessageBox.Show(" The Bike not found ");
        }

        private void btnREMOVE_Click_1(object sender, EventArgs e)
        {
            indexM = this.listBoxMontain.SelectedIndex;
            indexR = this.listBoxRoad.SelectedIndex;

            DialogResult result;
            result = MessageBox.Show("Do you want to delete this Bike ? ", "Delete",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                if (rdrMountain.Checked == true)
                {
                    if (indexM >= 0)
                    {
                        this.MountainBikeList.RemoveAt(indexM);
                    }

                    foreach (Control control in Controls)
                    {
                        this.txtHeight.Text = "";
                        this.txtSeat.Text = "";

                        if (control is TextBox)
                        {
                            control.Text = "";

                            this.cmbSuspension.Text = Convert.ToString(this.cmbSuspension.Items[0]);
                            this.cmbSize.Text = Convert.ToString(this.cmbSize.Items[0]);
                            this.lblsus.Visible = this.lblhgh.Visible = this.cmbSuspension.Visible = this.txtHeight.Visible = this.lblinchM.Visible = false;
                            this.lblset.Visible = this.lblsz.Visible = this.cmbSize.Visible = this.txtSeat.Visible = this.lblinchR.Visible = false;
                            this.rdrMountain.Checked = this.rdrRoad.Checked = false;
                        }
                    }
                    this.listBoxTextFile.Items.Clear();
                    this.listBoxMontain.Items.Clear();
                    this.listBoxRoad.Items.Clear();
                    this.txtSN.Focus();
                    MessageBox.Show("Selected Bike deleted from the list");
                }
                else if (rdrRoad.Checked == true)
                {
                    if (indexR >= 0)
                    {
                        this.RoadBikeList.RemoveAt(indexR);
                    }
                    foreach (Control control in Controls)
                    {
                        this.txtHeight.Text = "";
                        this.txtSeat.Text = "";

                        if (control is TextBox)
                        {
                            control.Text = "";

                            this.cmbSuspension.Text = Convert.ToString(this.cmbSuspension.Items[0]);
                            this.cmbSize.Text = Convert.ToString(this.cmbSize.Items[0]);
                            this.lblsus.Visible = this.lblhgh.Visible = this.cmbSuspension.Visible = this.txtHeight.Visible = this.lblinchM.Visible = false;
                            this.lblset.Visible = this.lblsz.Visible = this.cmbSize.Visible = this.txtSeat.Visible = this.lblinchR.Visible = false;
                            this.rdrMountain.Checked = this.rdrRoad.Checked = false;
                        }
                    }
                    this.listBoxTextFile.Items.Clear();
                    this.txtSN.Focus();
                    MessageBox.Show("Selected Bike deleted from the list");
                }
            }
            else MessageBox.Show("The selected Bike has not deleted from the list");
        }

        private void btnUPDATE_Click_1(object sender, EventArgs e)
        {



            indexM = this.listBoxMontain.SelectedIndex;
            indexR = this.listBoxRoad.SelectedIndex;
            DialogResult result;
            result = MessageBox.Show(" are you sure you want to make change on this Bike",
                                                            "Update", MessageBoxButtons.YesNo,
                                                                        MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                if (rdrMountain.Checked == true)
                {
                    long serialNumber = Convert.ToInt64(this.txtSN.Text);
                    string model = this.txtModel.Text;
                    string made = this.txtMade.Text;
                    EnumColor color = (EnumColor)positionMountain;
                    double weight = Convert.ToDouble(this.txtWeight.Text);
                    int tireSize = Convert.ToInt32(this.txtTire.Text);
                    EnumBikeType type = EnumBikeType.Mountain_Bike;
                    double speed = Convert.ToInt64(this.txtSpeed.Text);
                    int height = Convert.ToInt32(this.txtHeight.Text);
                    EnumMountain suspension = (EnumMountain)positionMountain;
                    double newSpeed = Convert.ToDouble(this.textNewS.Text);
                    int madeDate = Convert.ToInt32(this.txtDate.Text);

                    MountainBike aMountain = new MountainBike(type, serialNumber, made, model,
                                speed, color, madeDate, weight, tireSize, newSpeed, height, suspension);

                    this.MountainBikeList[indexM] = aMountain;


                    MessageBox.Show("Mountain Bike UPDATED");
                }
                else if (rdrRoad.Checked == true)
                {
                    long serialNumber = Convert.ToInt64(this.txtSN.Text);
                    string model = this.txtModel.Text;
                    string made = this.txtMade.Text;
                    EnumColor color = (EnumColor)positionColor;
                    double weight = Convert.ToDouble(this.txtWeight.Text);
                    int tireSize = Convert.ToInt32(this.txtTire.Text);
                    EnumBikeType type = EnumBikeType.Mountain_Bike;
                    double speed = Convert.ToInt64(this.txtSpeed.Text);
                    int seatHeight = Convert.ToInt32(this.txtSeat.Text);
                    EnumRoad size = (EnumRoad)positionRoad;
                    double newSpeed = Convert.ToDouble(this.textNewS.Text);
                    int madeDate = Convert.ToInt32(this.txtDate.Text);

                    RoadBike aRoad = new RoadBike(type, serialNumber, made, model,
                                speed, color, madeDate, weight, tireSize, newSpeed, seatHeight, size);

                    this.RoadBikeList[indexR] = aRoad;
                    MessageBox.Show("Road Bike UPDATED");
                }

            }
            else MessageBox.Show(" The selected Bike has not been  updated ");
        }

        private void btnRESET_Click_1(object sender, EventArgs e)
        {
            this.btnUPDATE.Visible = true;
            foreach (Control control in Controls)
            {
                this.txtHeight.Text = "";
                this.txtSeat.Text = "";

                if (control is TextBox)
                {
                    control.Text = "";

                    this.cmbSuspension.Text = Convert.ToString(this.cmbSuspension.Items[0]);
                    this.cmbSize.Text = Convert.ToString(this.cmbSize.Items[0]);
                    this.cmbColor.Text = Convert.ToString(this.cmbColor.Items[0]);
                    this.lblsus.Visible = this.lblhgh.Visible = this.cmbSuspension.Visible = this.txtHeight.Visible = this.lblinchM.Visible = false;
                    this.lblset.Visible = this.lblsz.Visible = this.cmbSize.Visible = this.txtSeat.Visible = this.lblinchR.Visible = false;
                    this.rdrMountain.Checked = this.rdrRoad.Checked = false;
                }
            }

            this.listBoxMontain.Items.Clear();
            this.listBoxRoad.Items.Clear();
            this.listBoxTextFile.Items.Clear();
            this.txtSN.Focus();
        }

        private void listBoxMontain_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            indexM = this.listBoxMontain.SelectedIndex;
            this.lblsus.Visible = this.lblhgh.Visible = this.cmbSuspension.Visible = this.txtHeight.Visible = this.lblinchM.Visible = true;
            this.lblset.Visible = this.lblsz.Visible = this.cmbSize.Visible = this.txtSeat.Visible = this.lblinchR.Visible = false;
            this.rdrMountain.Checked = true;
            this.rdrRoad.Checked = false;


            this.txtSN.Text = Convert.ToString(this.MountainBikeList[indexM].SerialNumber);
            this.txtMade.Text = this.MountainBikeList[indexM].Made;
            this.txtModel.Text = this.MountainBikeList[indexM].Model;
            this.cmbColor.Text = Convert.ToString(this.MountainBikeList[indexM].Color);
            this.txtDate.Text = Convert.ToString(this.MountainBikeList[indexM].MadeDate);
            this.txtWeight.Text = Convert.ToString(this.MountainBikeList[indexM].Weight);
            this.txtSpeed.Text = Convert.ToString(this.MountainBikeList[indexM].Speed);
            this.textNewS.Text = Convert.ToString(this.MountainBikeList[indexM].NewSpeed);
            this.txtTire.Text = Convert.ToString(this.MountainBikeList[indexM].TireSize);
            //this.MountainBikeList[indexM].Type = EnumBikeType.Mountain_Bike;
            this.cmbSuspension.Text = Convert.ToString(this.MountainBikeList[indexM].Suspension);
            this.txtHeight.Text = Convert.ToString(this.MountainBikeList[indexM].Height);
        }

        private void listBoxRoad_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            indexR = this.listBoxRoad.SelectedIndex;
            this.lblsus.Visible = this.lblhgh.Visible = this.cmbSuspension.Visible = this.txtHeight.Visible = this.lblinchM.Visible = false;
            this.lblset.Visible = this.lblsz.Visible = this.cmbSize.Visible = this.txtSeat.Visible = this.lblinchR.Visible = true;
            this.rdrMountain.Checked = false;
            this.rdrRoad.Checked = true;


            this.txtSN.Text = Convert.ToString(this.RoadBikeList[indexR].SerialNumber);
            this.txtMade.Text = this.RoadBikeList[indexR].Made;
            this.txtModel.Text = this.RoadBikeList[indexR].Model;
            this.cmbColor.Text = Convert.ToString(this.RoadBikeList[indexR].Color);
            this.txtDate.Text = Convert.ToString(this.RoadBikeList[indexR].MadeDate);
            this.txtWeight.Text = Convert.ToString(this.RoadBikeList[indexR].Weight);
            this.txtSpeed.Text = Convert.ToString(this.RoadBikeList[indexR].Speed);
            this.textNewS.Text = Convert.ToString(this.RoadBikeList[indexR].NewSpeed);
            this.txtTire.Text = Convert.ToString(this.RoadBikeList[indexR].TireSize);
            //this.RoadBikeList[indexR].Type = EnumBikeType.Road_Bike;
            this.cmbSize.Text = Convert.ToString(RoadBikeList[indexR].Size);
            this.txtSeat.Text = Convert.ToString(RoadBikeList[indexR].SeatHeight);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("\nThis app is created by: \n\t YASHAR AKISH ");
        }


    }
}
