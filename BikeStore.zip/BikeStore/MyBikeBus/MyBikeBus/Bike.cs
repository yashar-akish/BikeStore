﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBikeBus
{
    [System.Xml.Serialization.XmlInclude(typeof(MountainBike))]
    [System.Xml.Serialization.XmlInclude(typeof(RoadBike))]
    [Serializable]
    public abstract class Bike : IMovable
    {
        private long serialNumber;
        protected string made;
        protected string model;
        protected double speed;
        protected EnumColor color;
        protected int madeDate;
        protected double weight;
        protected int tireSize;
        protected EnumBikeType type;
        protected double newSpeed;

        public long SerialNumber { get => serialNumber; set => serialNumber = value; }

        public Bike() { }
        

        public Bike(EnumBikeType type, long serialNumber, string made, string model, double speed,
                                                EnumColor color, int madeDate, double weight, int tireSize, double newSpeed)
        {
            this.type = type;
            this.serialNumber = serialNumber;
            this.made = made;
            this.model = model;
            this.speed = speed;
            this.color = color;
            this.madeDate = madeDate;
            this.weight = weight;
            this.tireSize = tireSize;
            this.newSpeed = newSpeed;
        }

        public override string ToString() => "Bike: " + this.type + ":::  SN :" + this.serialNumber + ">> Made :" + this.made + ">> Model :" + this.model
                                        + ">> Speed :" + this.speed + ">> Color :" + this.color + ">> YEAR : " + this.madeDate + ">> WEIGHT : " + this.weight
                                        + ">> Size of Tire :" + this.tireSize;

        public virtual double GetMaxSpeed()
        {
            this.speed = 20;
            return this.speed;
        }
        public abstract void SpeedUp(double newSpeed);
    }
}
