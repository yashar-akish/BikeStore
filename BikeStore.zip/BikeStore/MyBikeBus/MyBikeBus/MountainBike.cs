﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBikeBus
{
    [Serializable]
    public class MountainBike : Bike
    {
        private int height;
        private EnumMountain suspension;

        public int Height { get => height; set => height = value; }
        public EnumMountain Suspension { get => suspension; set => suspension = value; }

        public string Made { get => made; set => made = value; }
        public string Model { get => model; set => model = value; }
        public double Weight { get => weight; set => weight = value; }
        public EnumBikeType Type { get => type; set => type = value; }
        public EnumColor Color { get => color; set => color = value; }
        public double Speed { get => speed; set => speed = value; }
        public int MadeDate { get => madeDate; set => madeDate = value; }
        public double NewSpeed { get => newSpeed; set => newSpeed = value; }
        public int TireSize { get => tireSize; set => tireSize = value; }


        public MountainBike():base() { }


        public MountainBike(EnumBikeType type, long serialNumber, string made, string model,
            double speed, EnumColor color, int madeDate, double weight, int tireSize, double newSpeed, int height, EnumMountain suspension)
                        : base(type, serialNumber, made, model,
                                speed, color, madeDate, weight, tireSize, newSpeed)
        {
            this.type = type;
            this.SerialNumber = serialNumber;
            this.made = made;
            this.model = model;
            this.speed = speed;
            this.color = color;
            this.madeDate = madeDate;
            this.weight = weight;
            this.tireSize = tireSize;
            this.newSpeed = newSpeed;
            this.height = height;
            this.suspension = suspension;
        }


        public override string ToString() => base.ToString() + ">> the Height is : " + this.Height
                                                + ">> type of Suspension : " + this.Suspension + " ::New Speed is : " + GetMaxSpeed();

        
        public override void SpeedUp(double newSpeed) => GetMaxSpeed();


        public override double GetMaxSpeed()
        {
            if ((this.speed + newSpeed) < base.GetMaxSpeed())
            {
                this.speed += this.newSpeed;
            }

            else
            {
                this.speed = this.newSpeed;
            }
                
            return this.speed;
        }

    }
}
