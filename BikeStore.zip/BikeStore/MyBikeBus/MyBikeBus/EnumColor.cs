﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikeBus
{
    public enum EnumColor
    {
        Undefined, White, Blue, Dark
    }
}