﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBikeBus
{
    [Serializable]
    public class RoadBike : Bike
    {
        private int seatHeight;
        private EnumRoad size;

        public int SeatHeight { get => seatHeight; set => seatHeight = value; }
        public EnumRoad Size { get => size; set => size = value; }


        public string Made { get => made; set => made = value; }
        public string Model { get => model; set => model = value; }
        public double Weight { get => weight; set => weight = value; }
        public EnumBikeType Type { get => type; set => type = value; }
        public EnumColor Color { get => color; set => color = value; }
        public double Speed { get => speed; set => speed = value; }
        public int MadeDate { get => madeDate; set => madeDate = value; }
        public double NewSpeed { get => newSpeed; set => newSpeed = value; }
        public int TireSize { get => tireSize; set => tireSize = value; }


        public RoadBike() : base() { }

        public RoadBike(EnumBikeType type, long serialNumber, string made, string model, double speed,
                                EnumColor color, int madeDate, double weight, int tireSize, double newSpeed, int seatHeight, EnumRoad size) :
                                                                 base(type, serialNumber, made, model, speed, color, madeDate, weight, tireSize, newSpeed)
        {
            this.type = type;
            this.SerialNumber = serialNumber;
            this.made = made;
            this.model = model;
            this.speed = speed;
            this.color = color;
            this.madeDate = madeDate;
            this.weight = weight;
            this.tireSize = tireSize;
            this.newSpeed = newSpeed;
            this.seatHeight = seatHeight;
            this.size = size;
        }

        public override string ToString() => base.ToString() + ">> the Seat Height is : " + this.SeatHeight
                                                + ">> The size is : " + this.Size + " ::New Speed is : " + GetMaxSpeed();

        
        public override void SpeedUp(double newSpeed) => GetMaxSpeed();
        public override double GetMaxSpeed()
        {
            if ((this.speed + newSpeed) < base.GetMaxSpeed())
            {
                this.speed += this.newSpeed;
            }

            else
            {
                this.speed = 40;
            }
                
            return this.speed;
        }
    }
}
