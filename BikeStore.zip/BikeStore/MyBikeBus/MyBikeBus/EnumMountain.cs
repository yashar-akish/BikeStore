﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyBikeBus
{
    public enum EnumMountain
    {
        Undefined, Front, Rear, Front_And_Rear
    }
}