﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;
using MyBikeBus;

namespace MyBikeData
{
    public class FileHandler
    {
        public static String xmlFilePath = @"../../data/my_bikes.xml";

        public static void WriteToXmlFile(List<Bike> list)
        {

            XmlWriter xw = XmlWriter.Create(xmlFilePath);

            XmlSerializer xs = new XmlSerializer(typeof(List<Bike>));

            xs.Serialize(xw, list);

            xw.Close();

        }
        public static List<Bike> ReadFromXmlFile()
        {
            List<Bike> list = null;

            StreamReader sr = new StreamReader(xmlFilePath);

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Bike>));

            list = (List<Bike>)xmlSerializer.Deserialize(sr);

            sr.Close();

            return list;
        }
    }
}
